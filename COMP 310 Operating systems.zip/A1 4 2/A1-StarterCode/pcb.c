#include <stdio.h>
#include <string.h>


PCB* createpcb(int id, int start, int end, int instruct){
    PCB* pcb = malloc(sizeof(PCB));
    pcb->id = id;
    pcb->start=start;
    pcb->end=end;
    pcb->instruct=instruct;
    return pcb;
}

