int parseInput(char ui[]);
