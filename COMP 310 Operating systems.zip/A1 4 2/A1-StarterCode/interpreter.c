#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "shellmemory.h"
#include "shell.h"
//#include "pcb.h"
//#include "shellmemory.c"

int MAX_ARGS_SIZE = 7;

 struct PCB{
    char* id;
    int start;
    int end;
    int instruct;
};

struct PCB pcb_array[10];

int help();
int quit();
int badcommand();
int setbadcommand();
int set(char* var, char* value);
int print(char* var);
int run(char* script);
int echo(char *value);
int exec(int argc, char* argv[]);
int my_ls();
int badcommandFileDoesNotExist();
int array_pcb_count = 0;
char* process_temp;


// Interpret commands and their arguments
int interpreter(char* command_args[], int args_size){
	int i;

	if ( args_size < 1 || args_size > MAX_ARGS_SIZE){
		if(strcmp(command_args[0],"set")==0){
			return setbadcommand(); // returns a modified bad token string for set
		}
		return badcommand();
	}


	for ( i=0; i<args_size; i++){ //strip spaces new line etc
		command_args[i][strcspn(command_args[i], "\r\n")] = 0;
	}

	if (strcmp(command_args[0], "help")==0){
	    //help
	    if (args_size != 1) return badcommand();
	    return help();

	} else if (strcmp(command_args[0], "quit")==0) {
		//quit
		if (args_size != 1) return badcommand();
		return quit();

	} else if (strcmp(command_args[0], "set")==0) {
		//set
		if (args_size > 7) return setbadcommand();
		else if(args_size<=3){
		return set(command_args[1], command_args[2]);
		}
		else {
			char array[500];
			strcpy(array,command_args[2]); // copies the second argument passed in stdin
			char *c = " ";
			strcat(array, c); // concatenates an empty space to array

			for(int i =3;i<args_size;i++){   // iterates through args and concatenates argument from the 4th place in stdin to array
				strcat(array,command_args[i]);
				strcat(array, c);
			}

			return set(command_args[1], array);
		}

	} else if (strcmp(command_args[0], "print")==0) {
		if (args_size != 2) return badcommand();
		return print(command_args[1]);

	} else if (strcmp(command_args[0], "run")==0) {
		if (args_size != 2) return badcommand();
		return run(command_args[1]);

	} else if (strcmp(command_args[0], "echo")==0){
		if(args_size != 2) return badcommand();
		return echo(command_args[1]);

	} else if (strcmp(command_args[0], "my_ls")==0){
		if(args_size != 1) return badcommand();
		return my_ls();

	} else if (strcmp(command_args[0], "exec")==0){
		if(args_size <1 || args_size >=6) return badcommand();
		return exec(args_size, command_args);
	} 
	
	else return badcommand();
}

int help(){

	char help_string[] = "COMMAND			DESCRIPTION\n \
help			Displays all the commands\n \
quit			Exits / terminates the shell with “Bye!”\n \
set VAR STRING		Assigns a value to shell memory\n \
print VAR		Displays the STRING assigned to VAR\n \
run SCRIPT.TXT		Executes the file SCRIPT.TXT\n ";
	printf("%s\n", help_string);
	return 0;
}

int quit(){
	printf("%s\n", "Bye!");
	exit(0);
}

int echo(char *value){
	char array[100];
	char temp2[100];
	strcpy(array,value); // copies the argument to array
	int length;
	if(array[0]=='$'){  // checks shellmemory if the first arg start with $
		length = strlen(value)-1;
		char temp[length];
		int i;
		value = value + 1;

		if(strcmp("Variable does not exist",mem_get_value(value))==0){ // prints a new line if the string matches
			printf("\n");
		} else {
			printf("%s \n", mem_get_value(value));  // prints the value from the memory
		}
	} else {
		printf("%s \n", value);
	}

	return 0;
}

int badcommand(){
	printf("%s\n", "Unknown Command");
	return 1;
}

// For run command only
int badcommandFileDoesNotExist(){
	printf("%s\n", "Bad command: File not found");
	return 60;
}

int set(char* var, char* value){

	char *link = "=";
	char buffer[1000];
	strcpy(buffer, var);
	strcat(buffer, link);
	strcat(buffer, value);

	mem_set_value(var, value);

	return 0;

}

int setbadcommand(){
	printf("%s\n", "Bad Command: Too many tokens");
	return 2;
}

int my_ls(){
	system("ls | sort -f"); //returns a sorted list
	return 0;
}

int print(char* var){
	printf("%s\n", mem_get_value(var));
	return 0;
}


struct PCB* createpcb(char* id, int start, int end, int instruct){
    struct PCB* pcb = malloc(sizeof(struct PCB));
    pcb->id = id;
    pcb->start=start;
    pcb->end=end;
    pcb->instruct=instruct;
    return pcb;
}

void scheduler(struct PCB pcb[]){
	char str[100];
	while(pcb[0].end!=0){
	char* s = pcb[0].id;
		if(strcmp("Variable does not exist",mem_get_value(s))!=0){
			char *temp = mem_get_value(s);
			parseInput(temp);
		}
		char b = (*pcb[0].id);
		b = b+1;
	//	printf("%c \n", b);
		str[0] = b;
		str[1] = '\0';
		pcb[0].id = str;
		pcb[0].end--;

	}
	mem_init();

}

int memory_pcb(char *q){
	char array[1000];
	char temp[1000];
	char temp2[1000];
	char *j;
	int i=0;
	char c = '0';
	int errc=0;
	int counter =1;

	FILE *p = fopen(q,"rt");  // the program is in a file
	if(p == NULL){
		return badcommandFileDoesNotExist();
	}
	while(1){
		if(feof(p)){
			struct PCB* process = createpcb(process_temp,c,counter-1,1);
			pcb_array[array_pcb_count] = *process;
			break;
		}
		fgets(array,999,p);
		
		temp[i]=c;
		temp[i+1]='\0';
		if(counter==1){
			j=strdup(temp);
			process_temp=j;
		}
		c=c+1;
		int k=0;
		mem_set_value(temp,array);	
		memset(array, 0, sizeof(array));
		k++;
		i=0;
		counter=counter+1;
	}
//	tdsd();
	scheduler(pcb_array);
	return errc;
}

int run(char* script){
	int errCode = 0;
	char line[1000];
	FILE *p = fopen(script,"rt");  // the program is in a file
	if(p == NULL){
		return badcommandFileDoesNotExist();
	}
	memory_pcb(script);	
    fclose(p);
	return errCode;

}

void scheduler_for_exec(struct PCB pcb[]){
	char str[100];
	int i=0;
	while(array_pcb_count>0){
		
	while(pcb[i].end!=0){
	char* s = pcb[i].id;
	
		if(strcmp("Variable does not exist",mem_get_value(s))!=0){
			char *temp = mem_get_value(s);
		
			parseInput(temp);
		}
	
		char b = (*pcb[i].id);
		b = b+1;
	
		str[0] = b;
		str[1] = '\0';
		pcb[i].id = str;
		
		pcb[i].end--;
	
	}
	i++;

	array_pcb_count--;
	}

	mem_init();
}

int memory_pcb_for_exec(char* command_args[],int args_size){
	char array[1000];
	char temp[1000];
	char temp2[1000];
	char *j;
	int i=0;
	char c = '0';
	int fcfs_inc=1;
	while(args_size-1>0){
	int counter =1;
	FILE *p = fopen(command_args[fcfs_inc],"rt");  // the program is in a file
	if(p == NULL){
		return badcommandFileDoesNotExist();
	}
	while(1){
	 	if(feof(p)){
	 		struct PCB* process = createpcb(process_temp,c,counter-1,1);
	 		pcb_array[array_pcb_count] = *process;
	 		fcfs_inc+=1;
	 		array_pcb_count+=1;
	 		break;
		}	
		fgets(array,999,p);
		temp[i]=c;
		temp[i+1]='\0';
		if(counter==1){
			j=strdup(temp);
			process_temp=j;
		}
		c=c+1;
		
		int k=0;
		mem_set_value(temp,array);	
		memset(array, 0, sizeof(array));
		k++;
		i=0;
		counter=counter+1;
	}
	args_size = args_size-1;
	fclose(p);
	 }
	
	scheduler_for_exec(pcb_array);
	return 0;
}


void scheduler_for_exec_sjf(struct PCB pcb[]){
	char str[100];
	int i=0;
	struct PCB pcbuparray[3];
	struct PCB p[3];
	for(int i=0;i<3;i++){
		p[i]=pcb[i];
	}
	if(array_pcb_count==2){
		if(pcb[0].end>pcb[1].end){
			pcbuparray[0]=pcb[1];
			pcbuparray[1]=pcb[0];
		}
		else if(pcb[1].end>pcb[0].end){
			pcbuparray[0]=pcb[0];
			pcbuparray[1]=pcb[1];
		}

		else if(pcb[1].end==pcb[0].end){
			pcbuparray[0]=pcb[0];
			pcbuparray[1]=pcb[1];
		}
		
	}
	else if(array_pcb_count==3){
		if(pcb[0].end > pcb[1].end && pcb[1].end > pcb[2].end){
			pcbuparray[0]=pcb[2];
			pcbuparray[1]=pcb[1];
			pcbuparray[2]=pcb[0];
		
		}
		else if(pcb[1].end > pcb[0].end && pcb[0].end > pcb[2].end){
			pcbuparray[0]=pcb[2];
			pcbuparray[1]=pcb[0];
			pcbuparray[2]=pcb[1];
			
		}

		else if(pcb[2].end > pcb[1].end && pcb[1].end > pcb[0].end){
			pcbuparray[0]=pcb[0];
			pcbuparray[1]=pcb[1];
			pcbuparray[2]=pcb[2];
		
		}

		else if(pcb[2].end > pcb[0].end && pcb[0].end > pcb[1].end){
			pcbuparray[0]=pcb[1];
			pcbuparray[1]=pcb[0];
			pcbuparray[2]=pcb[2];
			
		}

		else if(pcb[0].end > pcb[2].end && pcb[2].end > pcb[1].end){
			pcbuparray[0]=pcb[1];
			pcbuparray[1]=pcb[2];
			pcbuparray[2]=pcb[0];
		
		}

		else if(pcb[1].end > pcb[2].end && pcb[2].end > pcb[0].end){
			pcbuparray[0]=pcb[0];
			pcbuparray[1]=pcb[2];
			pcbuparray[2]=pcb[1];
			
		}

		else if(pcb[0].end == pcb[1].end && pcb[1].end>pcb[2].end){
			pcbuparray[0]=pcb[2];
			pcbuparray[1]=pcb[0];
			pcbuparray[2]=pcb[1];
			
		}

		else if(pcb[0].end == pcb[1].end && pcb[1].end<pcb[2].end){
			pcbuparray[0]=pcb[0];
			pcbuparray[1]=pcb[1];
			pcbuparray[2]=pcb[2];
		}

		else if(pcb[0].end == pcb[2].end && pcb[1].end<pcb[2].end){
			pcbuparray[0]=pcb[1];
			pcbuparray[1]=pcb[0];
			pcbuparray[2]=pcb[2];
		}

		else if(pcb[0].end == pcb[2].end && pcb[1].end>pcb[2].end){
			pcbuparray[0]=pcb[0];
			pcbuparray[1]=pcb[2];
			pcbuparray[2]=pcb[1];
		}

		else if(pcb[1].end == pcb[2].end && pcb[1].end>pcb[0].end){
			pcbuparray[0]=pcb[0];
			pcbuparray[1]=pcb[1];
			pcbuparray[2]=pcb[2];
		}

		else if(pcb[1].end == pcb[2].end && pcb[1].end < pcb[0].end){
			pcbuparray[0]=pcb[1];
			pcbuparray[1]=pcb[2];
			pcbuparray[2]=pcb[0];
		}

		else if(pcb[0].end == pcb[1].end && pcb[0].end == pcb[2].end){
			pcbuparray[0]=pcb[0];
			pcbuparray[1]=pcb[1];
			pcbuparray[2]=pcb[2];
		}

	}

	while(array_pcb_count>0){
		
	while(pcbuparray[i].end!=0){
	char* s = pcbuparray[i].id;
	
		if(strcmp("Variable does not exist",mem_get_value(s))!=0){
			char *temp = mem_get_value(s);
		
			parseInput(temp);
		}
	
		char b = (*pcbuparray[i].id);
		b = b+1;
	
		str[0] = b;
		str[1] = '\0';
		pcbuparray[i].id = str;
		
		pcbuparray[i].end--;
	
	}
	i++;

	array_pcb_count--;
	}

	mem_init();
}

int memory_pcb_for_exec_sjf(char* command_args[],int args_size){
	char array[1000];
	char temp[1000];
	char temp2[1000];
	char *j;
	int i=0;
	char c = '0';
	int fcfs_inc=1;
	while(args_size-1>0){
	int counter =1;
	FILE *p = fopen(command_args[fcfs_inc],"rt");  // the program is in a file
	if(p == NULL){
		return badcommandFileDoesNotExist();
	}
	while(1){
	 	if(feof(p)){
	 		struct PCB* process = createpcb(process_temp,c,counter-1,1);
	 		pcb_array[array_pcb_count] = *process;
	 		fcfs_inc+=1;
	 		array_pcb_count+=1;
	 		break;
		}	
		fgets(array,999,p);
		temp[i]=c;
		temp[i+1]='\0';
		if(counter==1){
			j=strdup(temp);
			process_temp=j;
		}
		c=c+1;
		
		int k=0;
		mem_set_value(temp,array);	
		memset(array, 0, sizeof(array));
		k++;
		i=0;
		counter=counter+1;
	}
	args_size = args_size-1;
	fclose(p);
	 }

	scheduler_for_exec_sjf(pcb_array);
	return 0;
}


void scheduler_for_exec_rr(struct PCB pcb[]){
	char str[100];
	char strfor1[100];
	char strfor2[100];
	int i=0;
	int terminate=0;
	int keeptab=10;
	char* lastid[array_pcb_count];
	struct PCB temppcb[array_pcb_count];
	int keeparraycount = array_pcb_count;

	temppcb[0]=pcb[0];
	temppcb[1]=pcb[1];
	temppcb[2]=pcb[2];

	while(array_pcb_count>0){

	while(temppcb[i].end!=0){
		if(keeptab==i){
			break;
		}

		if(strcmp("Variable does not exist",mem_get_value(temppcb[i].id))!=0){
			char *temp = mem_get_value(temppcb[i].id);
			parseInput(temp);
			terminate ++;
			
		}

		char b = *temppcb[i].id;
	
		b = b+1;
	
	if(i==0){
		str[0] = b;
		str[1] = '\0';
		temppcb[i].id = str;
		
		temppcb[i].end--;
	  }

	else if(i==1){
		strfor1[0]=b;
		strfor1[1]='\0';
		temppcb[i].id=strfor1;
		temppcb[i].end--;
	}

	else if(i==2){
		strfor2[0]=b;
		strfor2[1]='\0';
		temppcb[i].id=strfor2;
		temppcb[i].end--;
	}
	
	if(array_pcb_count>1){
		if(terminate == 2){ 

			break;
		}
	} 

	else if(array_pcb_count==1){
		if(temppcb[i].end==0){

			array_pcb_count--;
			break;
		}else {
			continue;
		}
	}
	}
	i++; 	

	if(temppcb[i-1].end == 0){

		array_pcb_count--;

		keeptab=i-1;
	}
	
	if(i==keeparraycount){
	
	if(keeptab==0 || keeptab==2){
		i=1;
	} else {
		i=0;
	}
	}
	
	terminate=0;

	}

	mem_init();
	array_pcb_count=0;
}

int memory_pcb_for_exec_rr(char* command_args[],int args_size){
	
	char array[1000];
	char temp[1000];
	char temp2[1000];
	char *j;
	int i=0;
	char c = '0';
	int fcfs_inc=1;
	while(args_size-1>0){
	int counter =1;
	FILE *p = fopen(command_args[fcfs_inc],"rt");  // the program is in a file
	if(p == NULL){
		return badcommandFileDoesNotExist();
	}
	while(1){
	 	if(feof(p)){
	 		struct PCB* process = createpcb(process_temp,c,counter-1,1);
	 		pcb_array[array_pcb_count] = *process;
	 		fcfs_inc+=1;
	 		array_pcb_count+=1;
	 		break;
		}	
		fgets(array,999,p);
		temp[i]=c;
		temp[i+1]='\0';
		if(counter==1){
			j=strdup(temp);
			process_temp=j;
		}
		c=c+1;
		
		int k=0;
		mem_set_value(temp,array);	
		memset(array, 0, sizeof(array));
		k++;
		i=0;
		counter=counter+1;
	}
		args_size = args_size-1;
		fclose(p);
	 }

	scheduler_for_exec_rr(pcb_array);
	return 0;
}


int exec(int argc, char* argv[]){
//	printf("%s", argv[1]);
	char* temp4343[100];
	temp4343[0]=strdup(argv[0]);

	if(argc==3 ){
		if(strcmp(argv[2],"SJF")==0){
		FILE *p = fopen(argv[1],"rt");  // the program is in a file
		
		if(p == NULL){
		
		return badcommandFileDoesNotExist();
	}
		} else if(strcmp(argv[2],"RR")==0){
			FILE *p = fopen(argv[1],"rt");  // the program is in a file
	
	if(p == NULL){
	
		return badcommandFileDoesNotExist();
	}
		}
		else if (strcmp(argv[2],"FCFS")==0){
				FILE *p = fopen(argv[1],"rt");  // the program is in a file
	
	if(p == NULL){
	
		return badcommandFileDoesNotExist();
	}
		}
	}

	

	else if(argc==4){
		if(strcmp(argv[3],"SJF")==0){
		FILE *p = fopen(argv[1],"rt");  // the program is in a file
		FILE *q = fopen(argv[2],"rt");
		if(p == NULL || q==NULL){
		return badcommandFileDoesNotExist();
	}
		} else if(strcmp(argv[3],"RR")==0){
			FILE *p = fopen(argv[1],"rt");  // the program is in a file
			FILE *q = fopen(argv[2],"rt");
			
	      if(p == NULL || q==NULL ){
		return badcommandFileDoesNotExist();
	}
		}
		else if (strcmp(argv[3],"FCFS")==0){
				FILE *p = fopen(argv[1],"rt");  // the program is in a file
				FILE *q = fopen(argv[2],"rt");
	if(p == NULL || q==NULL){
		return badcommandFileDoesNotExist();
	}
		}
	}

	else if(argc==5){
		if(strcmp(argv[4],"SJF")==0){
		FILE *p = fopen(argv[1],"rt");  // the program is in a file
		FILE *q = fopen(argv[2],"rt");
		FILE *r = fopen(argv[3],"rt");
		if(p == NULL || q==NULL || r== NULL){
		return badcommandFileDoesNotExist();
	}
		} else if(strcmp(argv[4],"RR")==0){
			FILE *p = fopen(argv[1],"rt");  // the program is in a file
			FILE *q = fopen(argv[2],"rt");
			FILE *r = fopen(argv[3],"rt");
		if(p == NULL || q==NULL || r== NULL){
		
		return badcommandFileDoesNotExist();
	}
	
		}
		else if (strcmp(argv[4],"FCFS")==0){
				FILE *p = fopen(argv[1],"rt");  // the program is in a file
				FILE *q = fopen(argv[2],"rt");
				FILE *r = fopen(argv[3],"rt");
		if(p == NULL || q==NULL || r== NULL){
		
		return badcommandFileDoesNotExist();
	}
		}
	}

	if(argc==3 && strcmp(argv[2],"FCFS")==0){
		temp4343[1]=strdup(argv[1]);
		memory_pcb_for_exec(temp4343,argc-1);
	}
	else if(argc==4 && strcmp(argv[3],"FCFS")==0){
		temp4343[1]=strdup(argv[1]);
		temp4343[2]=strdup(argv[2]);
		memory_pcb_for_exec(temp4343,argc-1);
	} 
	else if(argc==5 && strcmp(argv[4],"FCFS")==0){
		temp4343[1]=strdup(argv[1]);
		temp4343[2]=strdup(argv[2]);
		temp4343[3]=strdup(argv[3]);
		memory_pcb_for_exec(temp4343,argc-1);
	}
	if(argc==3 && strcmp(argv[2],"SJF")==0){
		temp4343[1]=strdup(argv[1]);
		memory_pcb_for_exec_sjf(temp4343,argc-1);
	}
	else if(argc==4 && strcmp(argv[3],"SJF")==0){
		temp4343[1]=strdup(argv[1]);
		temp4343[2]=strdup(argv[2]);
		memory_pcb_for_exec_sjf(temp4343,argc-1);
	} 
	else if(argc==5 && strcmp(argv[4],"SJF")==0){
		temp4343[1]=strdup(argv[1]);
		temp4343[2]=strdup(argv[2]);
		temp4343[3]=strdup(argv[3]);
		memory_pcb_for_exec_sjf(temp4343,argc-1);
	}

	if(argc==3 && strcmp(argv[2],"RR")==0){
		temp4343[1]=strdup(argv[1]);
		memory_pcb_for_exec_rr(temp4343,argc-1);
	}
	else if(argc==4 && strcmp(argv[3],"RR")==0){
		temp4343[1]=strdup(argv[1]);
		temp4343[2]=strdup(argv[2]);
		memory_pcb_for_exec_rr(temp4343,argc-1);
	} 
	else if(argc==5 && strcmp(argv[4],"RR")==0){
		temp4343[1]=strdup(argv[1]);
		temp4343[2]=strdup(argv[2]);
		temp4343[3]=strdup(argv[3]);
		memory_pcb_for_exec_rr(temp4343,argc-1);
	}
	
	else if(argc==2 && (strcmp(argv[1],"FCFS")!=0 && strcmp(argv[1],"SJF")!=0 && strcmp(argv[1],"RR")!=0)|| argc==3 && (strcmp(argv[2],"FCFS")!=0 && strcmp(argv[2],"SJF")!=0 && strcmp(argv[2],"RR")!=0) || argc==4 && (strcmp(argv[3],"FCFS")!=0 && strcmp(argv[3],"SJF")!=0 && strcmp(argv[3],"RR")!=0) || argc==5 && strcmp(argv[4],"FCFS")!=0 && strcmp(argv[4],"SJF")!=0 && strcmp(argv[4],"RR")!=0) {
		printf("add a policy and try again \n");
	}

	return 0;
}












