
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "interpreter.h"
#include "shellmemory.h"
#include "pcb.h"


int MAX_USER_INPUT = 1000;
int parseInput(char ui[]);

// Start of everything
int main(int argc, char *argv[]) {

	printf("%s\n", "Shell version 1.1 Created January 2022");
	help();

	char prompt = '$';  				// Shell prompt
	char userInput[MAX_USER_INPUT];		// user's input stored here
	int errorCode = 0;					// zero means no error, default
	char array[1000];
	//init user input
	for (int i=0; i<MAX_USER_INPUT; i++)
		userInput[i] = '\0';

	//init shell memory
	mem_init();

	while(1) {

		printf("%c ",prompt);
		fgets(userInput, MAX_USER_INPUT-1, stdin);


		errorCode = parseInput(userInput);
		if(feof(stdin)){
			freopen("/dev/tty","r",stdin);
		}
		if (errorCode == -1) exit(99);	// ignore all other errors
		memset(userInput, 0, sizeof(userInput));

	}

	return 0;
}

// Extract words from the input then call interpreter
int parseInput(char ui[]) {

	char tmp[200];
	char *words[100];
	char t[100];
	int a,b;
	int w=0; // wordID

	for(a=0; ui[a]==' ' && a<1000; a++);		// skip white spaces

	while(ui[a] != '\0' && a<1000) { // check to see if the character is not '\0'

		while(ui[a] != ';' && ui[a] != '\0' && a<1000){ // chech to see if ui is not ';' or '\0'

		for(b=0; ui[a]!='\0' && ui[a]!=' ' && a<1000 && ui[a]!=';'; a++, b++)
			tmp[b] = ui[a]; // each word

		tmp[b] = '\0';     // appends eof at the end

		words[w] = strdup(tmp);

		w++;

		if(ui[a] == '\0'){
			break;
		}

		if(ui[a]==';'){  // cheching if character at a is a ';'
			a = a+2;
			if(ui[a-1]=='\0'){		// checking if the index after ';' is a '\0'
				a=a-1;
				break;		// to break inner while loop
			}
			break;
		}
		a++;
		}
		if(interpreter(words, w)==-1) return -1;  // returns errorCode that is -1.
		w=0;
	}
		return 0;
}


// char* parseInput_up(char ui[]) {

// 	char tmp[200];
// 	char *words[100];
// 	char t[100];
// 	int a,b;
// 	int w=0; // wordID

// 	for(a=0; ui[a]==' ' && a<1000; a++);		// skip white spaces

// 	while(ui[a] != '\0' && a<1000) { // check to see if the character is not '\0'

// 		while(ui[a] != ';' && ui[a] != '\0' && a<1000){ // chech to see if ui is not ';' or '\0'

// 		for(b=0; ui[a]!='\0' && ui[a]!=' ' && a<1000 && ui[a]!=';'; a++, b++)
// 			tmp[b] = ui[a]; // each word

// 		tmp[b] = '\0';     // appends eof at the end

// 		words[w] = strdup(tmp);
// 		return tmp;
// 		w++;

// 		if(ui[a] == '\0'){
// 			break;
// 		}

// 		if(ui[a]==';'){  // cheching if character at a is a ';'
// 			a = a+2;
// 			if(ui[a-1]=='\0'){		// checking if the index after ';' is a '\0'
// 				a=a-1;
// 				break;		// to break inner while loop
// 			}
// 			break;
// 		}
// 		a++;
// 		}
// 		w=0;
// 	}
// }
