typedef struct PCB {
    int id;
    int start;
    int end;
    int instruction;
}PCB;

 PCB* createpcb(int id, int start, int end, int instruct);
